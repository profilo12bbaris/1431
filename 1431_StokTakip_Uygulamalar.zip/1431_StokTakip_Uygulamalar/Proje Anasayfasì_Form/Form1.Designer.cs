﻿namespace Proje_Anasayfası_Form
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuTedarikci = new System.Windows.Forms.Label();
            this.menuUrun = new System.Windows.Forms.Label();
            this.menuSatis = new System.Windows.Forms.Label();
            this.menuMusteri = new System.Windows.Forms.Label();
            this.menuPersonel = new System.Windows.Forms.Label();
            this.grdUrunListesi = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.mskTxtMusteriTelefon = new System.Windows.Forms.MaskedTextBox();
            this.txtMusteriAdSoyad = new System.Windows.Forms.TextBox();
            this.btnMusteriSec = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.btnEkle = new System.Windows.Forms.Button();
            this.ımageList2 = new System.Windows.Forms.ImageList(this.components);
            this.btnSil = new System.Windows.Forms.Button();
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.label19 = new System.Windows.Forms.Label();
            this.txtNot = new System.Windows.Forms.RichTextBox();
            this.btnSatisYap = new System.Windows.Forms.Button();
            this.ımageList4 = new System.Windows.Forms.ImageList(this.components);
            this.label20 = new System.Windows.Forms.Label();
            this.txtGenelToplam = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Miktar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Toplam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Kod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2grdSatilacakUrunler = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.grdUrunListesi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2grdSatilacakUrunler)).BeginInit();
            this.SuspendLayout();
            // 
            // menuTedarikci
            // 
            this.menuTedarikci.AutoSize = true;
            this.menuTedarikci.Location = new System.Drawing.Point(13, 13);
            this.menuTedarikci.Name = "menuTedarikci";
            this.menuTedarikci.Size = new System.Drawing.Size(91, 13);
            this.menuTedarikci.TabIndex = 0;
            this.menuTedarikci.Text = "Tedarikci İşlemleri";
            // 
            // menuUrun
            // 
            this.menuUrun.AutoSize = true;
            this.menuUrun.Location = new System.Drawing.Point(111, 13);
            this.menuUrun.Name = "menuUrun";
            this.menuUrun.Size = new System.Drawing.Size(73, 13);
            this.menuUrun.TabIndex = 1;
            this.menuUrun.Text = "Ürün  İşlemleri";
            // 
            // menuSatis
            // 
            this.menuSatis.AutoSize = true;
            this.menuSatis.Location = new System.Drawing.Point(190, 13);
            this.menuSatis.Name = "menuSatis";
            this.menuSatis.Size = new System.Drawing.Size(77, 13);
            this.menuSatis.TabIndex = 2;
            this.menuSatis.Text = "Satış  Detaylari";
            // 
            // menuMusteri
            // 
            this.menuMusteri.AutoSize = true;
            this.menuMusteri.Location = new System.Drawing.Point(274, 12);
            this.menuMusteri.Name = "menuMusteri";
            this.menuMusteri.Size = new System.Drawing.Size(81, 13);
            this.menuMusteri.TabIndex = 3;
            this.menuMusteri.Text = "Musteri İşlemleri";
            // 
            // menuPersonel
            // 
            this.menuPersonel.AutoSize = true;
            this.menuPersonel.Location = new System.Drawing.Point(362, 11);
            this.menuPersonel.Name = "menuPersonel";
            this.menuPersonel.Size = new System.Drawing.Size(100, 13);
            this.menuPersonel.TabIndex = 5;
            this.menuPersonel.Text = " Personler İslemeleri";
            // 
            // grdUrunListesi
            // 
            this.grdUrunListesi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grdUrunListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdUrunListesi.Location = new System.Drawing.Point(12, 45);
            this.grdUrunListesi.MultiSelect = false;
            this.grdUrunListesi.Name = "grdUrunListesi";
            this.grdUrunListesi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdUrunListesi.Size = new System.Drawing.Size(450, 392);
            this.grdUrunListesi.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Ürün Listeleri";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(492, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Satış İşlemleri";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.CausesValidation = false;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.SteelBlue;
            this.label8.Location = new System.Drawing.Point(679, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "Personel Adi";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(843, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Yetki";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(495, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Müsteri Telefon";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(498, 103);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Müsteri";
            // 
            // mskTxtMusteriTelefon
            // 
            this.mskTxtMusteriTelefon.Location = new System.Drawing.Point(600, 65);
            this.mskTxtMusteriTelefon.Mask = "(999) 000-0000";
            this.mskTxtMusteriTelefon.Name = "mskTxtMusteriTelefon";
            this.mskTxtMusteriTelefon.Size = new System.Drawing.Size(100, 20);
            this.mskTxtMusteriTelefon.TabIndex = 15;
            // 
            // txtMusteriAdSoyad
            // 
            this.txtMusteriAdSoyad.Enabled = false;
            this.txtMusteriAdSoyad.Location = new System.Drawing.Point(600, 103);
            this.txtMusteriAdSoyad.Name = "txtMusteriAdSoyad";
            this.txtMusteriAdSoyad.Size = new System.Drawing.Size(100, 20);
            this.txtMusteriAdSoyad.TabIndex = 16;
            // 
            // btnMusteriSec
            // 
            this.btnMusteriSec.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMusteriSec.ImageIndex = 0;
            this.btnMusteriSec.ImageList = this.ımageList1;
            this.btnMusteriSec.Location = new System.Drawing.Point(757, 73);
            this.btnMusteriSec.Name = "btnMusteriSec";
            this.btnMusteriSec.Size = new System.Drawing.Size(77, 58);
            this.btnMusteriSec.TabIndex = 17;
            this.btnMusteriSec.Text = "Sec";
            this.btnMusteriSec.UseVisualStyleBackColor = true;
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "Topluluk.png");
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.26F);
            this.label12.Location = new System.Drawing.Point(700, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(130, 15);
            this.label12.TabIndex = 18;
            this.label12.Text = "Satisi Yapılcak Ürünler";
            // 
            // btnEkle
            // 
            this.btnEkle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEkle.ImageIndex = 0;
            this.btnEkle.ImageList = this.ımageList2;
            this.btnEkle.Location = new System.Drawing.Point(479, 161);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(80, 23);
            this.btnEkle.TabIndex = 25;
            this.btnEkle.Text = "Ekle";
            this.btnEkle.UseVisualStyleBackColor = true;
            // 
            // ımageList2
            // 
            this.ımageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList2.ImageStream")));
            this.ımageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList2.Images.SetKeyName(0, "İleri.png");
            // 
            // btnSil
            // 
            this.btnSil.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSil.ImageIndex = 0;
            this.btnSil.ImageList = this.ımageList3;
            this.btnSil.Location = new System.Drawing.Point(484, 258);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(75, 23);
            this.btnSil.TabIndex = 26;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            // 
            // ımageList3
            // 
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "Geri.png");
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(499, 358);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 13);
            this.label19.TabIndex = 28;
            this.label19.Text = "Not Ekle";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtNot
            // 
            this.txtNot.Location = new System.Drawing.Point(570, 341);
            this.txtNot.Name = "txtNot";
            this.txtNot.Size = new System.Drawing.Size(333, 58);
            this.txtNot.TabIndex = 29;
            this.txtNot.Text = "";
            // 
            // btnSatisYap
            // 
            this.btnSatisYap.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSatisYap.ImageIndex = 0;
            this.btnSatisYap.ImageList = this.ımageList4;
            this.btnSatisYap.Location = new System.Drawing.Point(570, 414);
            this.btnSatisYap.Name = "btnSatisYap";
            this.btnSatisYap.Size = new System.Drawing.Size(104, 23);
            this.btnSatisYap.TabIndex = 30;
            this.btnSatisYap.Text = "Satış Yap";
            this.btnSatisYap.UseVisualStyleBackColor = true;
            // 
            // ımageList4
            // 
            this.ımageList4.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList4.ImageStream")));
            this.ımageList4.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList4.Images.SetKeyName(0, "Alisveris Sepeti.png");
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(706, 423);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(73, 13);
            this.label20.TabIndex = 31;
            this.label20.Text = "Genel Toplam";
            // 
            // txtGenelToplam
            // 
            this.txtGenelToplam.Enabled = false;
            this.txtGenelToplam.Location = new System.Drawing.Point(785, 416);
            this.txtGenelToplam.Name = "txtGenelToplam";
            this.txtGenelToplam.Size = new System.Drawing.Size(86, 20);
            this.txtGenelToplam.TabIndex = 32;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(895, 424);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(13, 13);
            this.label21.TabIndex = 34;
            this.label21.Text = "₺";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Ürün Adi";
            this.Column1.Name = "Column1";
            // 
            // Miktar
            // 
            this.Miktar.HeaderText = "Miktar";
            this.Miktar.Name = "Miktar";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "BirimFiyat";
            this.Column2.Name = "Column2";
            // 
            // Toplam
            // 
            this.Toplam.HeaderText = "Toplam";
            this.Toplam.Name = "Toplam";
            // 
            // Kod
            // 
            this.Kod.HeaderText = "Kod";
            this.Kod.Name = "Kod";
            // 
            // dataGridView2grdSatilacakUrunler
            // 
            this.dataGridView2grdSatilacakUrunler.AllowUserToAddRows = false;
            this.dataGridView2grdSatilacakUrunler.AllowUserToDeleteRows = false;
            this.dataGridView2grdSatilacakUrunler.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2grdSatilacakUrunler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2grdSatilacakUrunler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Kod,
            this.Toplam,
            this.Column2,
            this.Miktar,
            this.Column1});
            this.dataGridView2grdSatilacakUrunler.Location = new System.Drawing.Point(575, 154);
            this.dataGridView2grdSatilacakUrunler.MultiSelect = false;
            this.dataGridView2grdSatilacakUrunler.Name = "dataGridView2grdSatilacakUrunler";
            this.dataGridView2grdSatilacakUrunler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2grdSatilacakUrunler.Size = new System.Drawing.Size(333, 160);
            this.dataGridView2grdSatilacakUrunler.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 440);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txtGenelToplam);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.btnSatisYap);
            this.Controls.Add(this.txtNot);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.btnEkle);
            this.Controls.Add(this.dataGridView2grdSatilacakUrunler);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btnMusteriSec);
            this.Controls.Add(this.txtMusteriAdSoyad);
            this.Controls.Add(this.mskTxtMusteriTelefon);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.grdUrunListesi);
            this.Controls.Add(this.menuPersonel);
            this.Controls.Add(this.menuMusteri);
            this.Controls.Add(this.menuSatis);
            this.Controls.Add(this.menuUrun);
            this.Controls.Add(this.menuTedarikci);
            this.Name = "Form1";
            this.Text = "STOKTakipFormu";
            ((System.ComponentModel.ISupportInitialize)(this.grdUrunListesi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2grdSatilacakUrunler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label menuTedarikci;
        private System.Windows.Forms.Label menuUrun;
        private System.Windows.Forms.Label menuSatis;
        private System.Windows.Forms.Label menuMusteri;
        private System.Windows.Forms.Label menuPersonel;
        private System.Windows.Forms.DataGridView grdUrunListesi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.MaskedTextBox mskTxtMusteriTelefon;
        private System.Windows.Forms.TextBox txtMusteriAdSoyad;
        private System.Windows.Forms.Button btnMusteriSec;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.ImageList ımageList2;
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RichTextBox txtNot;
        private System.Windows.Forms.Button btnSatisYap;
        private System.Windows.Forms.ImageList ımageList4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtGenelToplam;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Miktar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Toplam;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kod;
        private System.Windows.Forms.DataGridView dataGridView2grdSatilacakUrunler;
    }
}


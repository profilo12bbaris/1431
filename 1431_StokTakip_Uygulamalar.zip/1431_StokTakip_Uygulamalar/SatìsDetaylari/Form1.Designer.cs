﻿namespace SatısDetaylari
{
    partial class frmSatisDetaylarii
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSatisDetaylarii));
            this.label1 = new System.Windows.Forms.Label();
            this.grdSatislar = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.grd_satıslar = new System.Windows.Forms.Label();
            this.grdSatilanUrunler = new System.Windows.Forms.RichTextBox();
            this.btnSatisIptal = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSatisToplam = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grdSatislar)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Satış Listesi";
            // 
            // grdSatislar
            // 
            this.grdSatislar.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grdSatislar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdSatislar.Location = new System.Drawing.Point(7, 43);
            this.grdSatislar.MultiSelect = false;
            this.grdSatislar.Name = "grdSatislar";
            this.grdSatislar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdSatislar.Size = new System.Drawing.Size(402, 185);
            this.grdSatislar.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(431, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Satış Detaylari";
            // 
            // grd_satıslar
            // 
            this.grd_satıslar.AutoSize = true;
            this.grd_satıslar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grd_satıslar.Location = new System.Drawing.Point(511, 68);
            this.grd_satıslar.Name = "grd_satıslar";
            this.grd_satıslar.Size = new System.Drawing.Size(132, 24);
            this.grd_satıslar.TabIndex = 11;
            this.grd_satıslar.Text = "Satılan Ürünler";
            // 
            // grdSatilanUrunler
            // 
            this.grdSatilanUrunler.Location = new System.Drawing.Point(434, 113);
            this.grdSatilanUrunler.Name = "grdSatilanUrunler";
            this.grdSatilanUrunler.Size = new System.Drawing.Size(354, 81);
            this.grdSatilanUrunler.TabIndex = 12;
            this.grdSatilanUrunler.Text = "";
            // 
            // btnSatisIptal
            // 
            this.btnSatisIptal.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSatisIptal.ForeColor = System.Drawing.Color.RosyBrown;
            this.btnSatisIptal.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSatisIptal.ImageIndex = 0;
            this.btnSatisIptal.ImageList = this.ımageList1;
            this.btnSatisIptal.Location = new System.Drawing.Point(434, 214);
            this.btnSatisIptal.Name = "btnSatisIptal";
            this.btnSatisIptal.Size = new System.Drawing.Size(149, 53);
            this.btnSatisIptal.TabIndex = 13;
            this.btnSatisIptal.Text = "Satısı İptal Et";
            this.btnSatisIptal.UseVisualStyleBackColor = true;
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "sell cancel.png");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(592, 234);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Satış Toplam Fiyat";
            // 
            // txtSatisToplam
            // 
            this.txtSatisToplam.Enabled = false;
            this.txtSatisToplam.Location = new System.Drawing.Point(691, 231);
            this.txtSatisToplam.Name = "txtSatisToplam";
            this.txtSatisToplam.Size = new System.Drawing.Size(49, 20);
            this.txtSatisToplam.TabIndex = 15;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(746, 234);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(13, 13);
            this.label21.TabIndex = 35;
            this.label21.Text = "₺";
            // 
            // frmSatisDetaylarii
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 299);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txtSatisToplam);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnSatisIptal);
            this.Controls.Add(this.grdSatilanUrunler);
            this.Controls.Add(this.grd_satıslar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.grdSatislar);
            this.Controls.Add(this.label1);
            this.Name = "frmSatisDetaylarii";
            this.Text = "FrmSatisDetaylari";
            ((System.ComponentModel.ISupportInitialize)(this.grdSatislar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView grdSatislar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label grd_satıslar;
        private System.Windows.Forms.RichTextBox grdSatilanUrunler;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button btnSatisIptal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSatisToplam;
        private System.Windows.Forms.Label label21;
    }
}


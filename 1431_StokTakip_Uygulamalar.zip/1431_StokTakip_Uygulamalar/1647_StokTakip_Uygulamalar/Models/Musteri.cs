﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1647_StokTakip_Uygulamalar.Models
{
    public class Musteri
    {
        [Key]

        public string id { get; set; }

        public string KategoriAdi { get; set; }

        public virtual ICollection<Urun>Urunler { get; set; } =new HashSet<Urun>();
    }
}
